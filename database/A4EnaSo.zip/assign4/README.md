

JUST TO ADD NOTE 

** clear button is deactivated when there is no files in upload folder but it is not greyed out, functionality is all fine, so I have an alert that reminds you that is is deactivated



** when you press help button after table is displayed it will stay there until you refresh the page. 


